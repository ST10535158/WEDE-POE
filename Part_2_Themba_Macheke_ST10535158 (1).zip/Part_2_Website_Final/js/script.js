// Part 2: basic client-side interaction for the enquiry form
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("enquiryForm");
  const message = document.getElementById("formMessage");

  if (form && message) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      message.textContent = "Thank you. Your enquiry has been captured for this demonstration.";
      form.reset();
    });
  }
});
